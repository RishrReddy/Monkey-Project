package sanctuary;

/**
 * Sex is an enumeration which provides
 * possible values for primate's gender : MALE or FEMALE.
 */
public enum Sex {
  FEMALE, MALE
}
