package sanctuary;

/**
 * Size is an enumeration which provides
 * possible values for primate's size :
 * SMALL, MEDIUM, LARGE.
 */
public enum Size {
  SMALL, MEDIUM, LARGE
}
