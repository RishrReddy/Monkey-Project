package sanctuary;

/**
 * Species is an enumeration which provides
 * possible values for primate's type
 * DRILL, GUEREZA, HOWLER, MANGABEU, SAKI, SPIDER, SQUIRREL, TAMARIN.
 */
public enum Species {
  DRILL, GUEREZA, HOWLER, MANGABEU, SAKI, SPIDER, SQUIRREL, TAMARIN
}
