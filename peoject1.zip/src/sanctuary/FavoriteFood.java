package sanctuary;

/**
 * FavoriteFood is an enumeration which provides
 * possible values for primate's favorite food :
 * EGGS, FRUITS, INSECTS, LEAVES, NUTS, SEEDS, TREESAP.
 */
public enum FavoriteFood {
  EGGS, FRUITS, INSECTS, LEAVES, NUTS, SEEDS, TREESAP
}
